---
title: "Need, Greed, Ambition"
date: 2020-08-20T19:55:45+07:00
---

We are living in the very materialistic society order. I think it is important that we learn to split the different of words such __Need, Greed, Ambition__.

To me, __need__ is a necessity. You need something to live and function. Or you need something, otherwise you can't do the work you love. 

Whereas __greed__ is a selfish act to get what you want with the expense of others.

__Ambition__, on the other hand, is a desire to achieve something __BIG__ for the benefits of many. For example, Gautama Buddha had a great ambition, because he left the lavish life to find ways to end suffering -- not only for himself but for all.

Going through life, we will encounter many that are crossing paths with our life. Many of whom are born fresh and clean, but material society of ours turned them to become more selfish and greedy. 

Many cause from not able to fulfill their needs. Many casued from not able to distiguish the different between __need__ and __greed__. Most can't find their passion, thus do not have __ambition__ or a __purpose to being__, like mentioned in a book title __IKIGAI__. 

If you have pure __ambition__, you would certaintly have __purpose to being__. Then, you would feel like your work is part of your evolutionary development. You'd be more active and more energetic with what you do. 

When you are active, you have no time for stress. So you would certaintly live longer and more happy.

Having __ambition__ is a very good thing, as long as it is not currupted, when you reach a certain stage. Many people got drunk with materials and power.

To keep oneself away from currupting the original __ambition__, ones must stay conscious of their root, where they come from or another word their __IKIGAI__. Another word, ones should have __IKIGASM__ more often. 
