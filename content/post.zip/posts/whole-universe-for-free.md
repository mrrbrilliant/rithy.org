---
title: "A whole universe for free"
date: 2020-06-13T10:58:53+07:00
---

I am grateful that the universe happened the way it is. I am grateful that life happen the way it is.

The univese is a great work of art, done so well by unkown force. It's so perfect that if it made even smaller than a yocto mistake, all life as we know it would not ever existed.

Yet, we have inherit this whole universe for free. At the same time, many of us are strugling to live life, because of the society men designed. 

If we live more with the universe rules, we might be more happy and contents. 

Take energy and water, the most important elements that support life.

Everyday we have more than 1 trillion MWh of powered striking the Earth from our Sun through radian light and heat. But for the last hundred years, we dig holes to get old to power our lives. Even now with all the tech we have, we should learn to harness the Sun's energy instead. 

Water too is every where around us, done by the sun as well. We we work with nature in synergy with the universe's language -- math & physic, we would have less problem.

Though, people tend to live with limit resource due to society we born and  live in. If one day, most people learn how to live and embrace the free of charge universe. Our way of would get much better, in my opinion.

**Note**: yocto is scale that equal to `10` to the power of `-24`. Read more about [Yocto](https://en.wikipedia.org/wiki/Yocto-) on Wikipedia.