---
title: "Everything made out of nothing"
date: 2020-06-13T10:58:53+07:00
---

What created our universe? 

Modern scientists agreed that the universe made from the big bang? Before the big bang there was nothing but a small dent point of energy which was unknown of it origin either.

Keep god and others force aside, we could conclude that universe was made out of nothing. The whole universe, everything we knew and everything that made us happy and sad -- and everything else was made out of nothing.

Is nothing our origin? Base on this, it may be is true. If that why do we try so hard to make new things. We should go back and work with the origin, because it made everything that come to existen.

If we could have a whole universe from nothing, everything we will ever need will also come from nothing. Nothing is everything, everything is nothing. 

Sound strange but think about it. Take a day to meditate on it.