---
title: "Just for Today"
date: 2020-10-22T15:46:43+07:00
draft: false
---
Today, I will TREAT my energy as money. I budget it, save it, find away to increase it, invest it where I would get a return.

Our energy is our true currency. Money is just a symbolic exchange of energy. This is why I must pay more attention on my energy, and invest much more wisely.

Today, I will TEAT my time as money. Because life is nothing without time, doesn't matter how much money we have. Time is the gift that is given to all of us fairly, roughly around 24 hours a day, 365 days a year. Time is finite. It is limited to only lifetime each.

Even if I will live for 80 year old, 150 year old or 1000 year old, it's still a limited to those amount. These number are clearly limited, not eternity. Even the life of the universe itself will end one day. One day there will be no time. There might be no nothingness either. Our human mind can't not comprehend that kind of time at that scale. So I will focus on today. 

I must spend less time and invest time more wisely into what matter most. So I could have more time to do things that are more matter to me and people around me and experience the life I live to its maximum potential.

Today, I will ATTAIN more of these universally free gifts by giving; SMILES, LAUGH, DREAM, COURAGE, and TIME.

By giving smiles, I will ATTAIN smiles in return. By make people laugh, I will be returned happy myself and get more laughter. By helping people dream and achieve their own dream, I could achieve of my. Sometime, they achieve it for me, because some dream I lend to them by helping them. By giving courage, I gain more courage to give more hope. By investing time in people that value their own time, we both will gain lot more time.

Today is the day when the past is a lesson and the future is to be written fresh. I will TREAT today as the biggest present of my life. Thus, I am grateful for TODAY and everything today present to me. Today, I do everything just for today.