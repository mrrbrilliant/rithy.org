---
title: "Continue writting"
date: 2020-07-30T20:58:53+07:00
---

[rithy.org](http://rithy.org) is my personal space for self-expression online. A collection of record of my experiences going through life full wonder and challenges. Some of the reflection is an advice to my future Self, while some hope to be mirror for some younger people to avoid mistakes I have made over the years.

Mid-day of November 14 was when my life truely begun. The first time I truely left home to go into the world outside of my parents' oversight and to pursuit something unknown. I have been fortunate to have met many kind and wonderful human being that showed me being human is super wonderful. While some were lessons to be voide, many others become close friends, mentors, and business partners. 

I have received so much positive support from them, that now has become my time to pay forward to others through my writing here. I write about my thought & reflection of my being, experiences, principles, philosophy, work and play. Hope this will help some people who can make good use of it.

I hope to one day to contribute bigger things, than just writing. For now, will let's things flow and happen on its own. I am here in this life to expiriment and learn. 

I am thankful that our life somehow has crossed paths. May it crossed again and again. 
