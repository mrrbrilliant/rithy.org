---
title: "Treat as it is your LIFE"
date: 2020-10-22T11:25:44+07:00
---

### Lets TREAT our food as our LIFE.

If we low or hurt part of our LIFE, we suffer and live disease ( DIS + EASE). Not easy.

We forget that food give us our LIFE. All the food we eat should be treated as holy medicine. So when it goes into our body, it's become our medicine to heal us and give us strange.

If there is left over that is still good. Don't put it in the trash. If  you put it in the trash, it's like you cut part of your body and throw into trash.

### Lets TREAT our energy as our LIFE.

All life on earth depend on the sun. Sadly, we can't eat sunlight directly, so we depend on the Earth and other lives on Earth to help transform sunlight to energy we can consume and use. 

The light that our home comes from them. The AC we use to comfort us also comes from them. Our food we eat, veggies and meats are also come from them. If we don't TREAT this energy as our LIFE, those lives are going to work much harder to feed us. The harder they work, the sooner they are burning out. If they burn out, we doomed.

### Lets TREAT our work as our LIFE.

We sleep around 6 - 8 hours per day. We work around 5 - 10 hours a day. Some do a little more, while some do a little less. The rest is for eating, playing and socializing.

Thus, work takes up around 1/3 of our life. If the work you do, don't give you pride and hope that lift up your life, do have the courage to venture away and seek for what resonate to your LIFE. 

If the work you are doing give you meaning to your life, treat it as it is. Because like all else, it will passes by quickly. Give it the meaning it gives you. So the relationship between you and the work will be peaceful and rewarding. 

Better than that, more 30% of your life's meaning is taken care of by that relationship.

### Lets TREAT our homeoffice as our LIFE.
This is more about KOOMPI Boran Research Lab, rather than your home. Though, for some who work at KOOMPI, not all, have spend most of their waking up hour there. That mean, it is almost more than your home. 

If it's your home, treat it as it is. Because it's will give young more clear head to live and benefit your work life relationship, thus improve you quality of life in general. 

Let's take care of our home office or any office you go to work. Keep it clean and organize. Make it among the most relaxing place to work and live in. 

Let's do that. Inspire other to do as well. Thank you for reading this.